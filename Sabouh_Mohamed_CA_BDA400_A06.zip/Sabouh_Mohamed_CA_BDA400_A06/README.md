# BDA400 Assignment 6 – Technical Analysis using R, Visualization Phase
**Student:** Sabouh Mohamed  
**Course:** BDA400 – Data Science Tools and Techniques  
**Deliverable:** R Shiny stock portfolio dashboard

## Install and run
Open the folder in RStudio. Run in the R Console:

```r
install.packages(c('shiny','ggplot2','quantmod','TTR','xts','zoo'))
shiny::runApp('.')
```

Requires an internet connection to Yahoo Finance. Default symbol is AAPL; presets support MSFT, GOOG, NVDA and TSLA. Select date range, daily/weekly/monthly bars, chart type, and toggle indicators on or off. SMA short/long lengths and RSI length are configurable. Buy and Sell annotations mark changes in short-vs-long SMA ordering from the previous bar; otherwise Hold. Historical technical indicators are for educational use.

## How each rubric criterion is covered
- **Data collection:** `quantmod::getSymbols(...,src='yahoo')`, basic input validation, request error messages.
- **Dynamic visuals:** R Shiny reactive data flow; line, area, and candlestick representations; date and timeframe controls.
- **Indicators:** SMA overlays on the price pane, RSI and MACD in separate aligned time-series panes (different numeric scales). Checkboxes toggle their display.
- **Trading rules:** Detects actual SMA crossovers; plots and labels Buy/Sell events; table includes Hold.
- **Extra:** Download the calculated time series as CSV.

## Suggested evaluation steps
1. Run app with AAPL and a two-year Daily range; check that all graphs and table appear.
2. Switch to Weekly then Monthly; confirm bar count changes.
3. Toggle each indicator and signals checkbox; verify panes/annotations update.
4. Change short/long SMA lengths and inspect Buy/Sell signals.
5. Try an invalid ticker to confirm a readable error; export CSV to review calculations.

## Known constraints
- Live network access and RStudio execution must be verified on your computer.
- Yahoo Finance can rate-limit, block requests, or have missing symbols.
- Unadjusted closes are used for consistent OHLC candlestick chart calculations; stock splits/dividends can influence old data.
- Insufficient history produces NA indicators; expand date range if needed.
- This app does not execute trades or calculate brokerage portfolio returns.

## Submission
Push this folder to a **public GitHub repository**, edit `Cover_Page.pdf` / `COVER_PAGE.txt` with your real repository URL, and submit the cover page and repository link through LMS. Do not submit a placeholder URL.
