# BDA400 Assignment 6 - Portfolio Visualization Dashboard
# Student: Sabouh Mohamed | Data source: Yahoo Finance via quantmod
# Run: shiny::runApp('.') from this folder. Internet needed for Yahoo Finance.
required_packages <- c('shiny', 'ggplot2', 'quantmod', 'TTR', 'xts')
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly=TRUE)]
if (length(missing_packages)) stop('Install the following packages first: ', paste(missing_packages, collapse=', '))
library(shiny)
library(ggplot2)
library(quantmod)

# Input validation and deterministic calculations.
validate_symbol <- function(symbol) {
  symbol <- toupper(trimws(symbol))
  if (!grepl('^[A-Z0-9.^_-]{1,15}$', symbol)) stop('Invalid stock symbol.')
  symbol
}

# Resample OHLCV data in xts, ensuring all indicators use matching bar frequencies.
resample_ohlcv <- function(x, frame) {
  if (frame == 'Weekly') return(xts::to.weekly(x, indexAt='endof', drop.time=TRUE, name=NULL))
  if (frame == 'Monthly') return(xts::to.monthly(x, indexAt='endof', drop.time=TRUE, name=NULL))
  x
}

make_analysis <- function(x, short_n, long_n, rsi_n, fast_n, slow_n, signal_n) {
  close <- as.numeric(quantmod::Cl(x))
  n <- length(close)
  df <- data.frame(Date=as.Date(zoo::index(x)), Open=as.numeric(quantmod::Op(x)),
                   High=as.numeric(quantmod::Hi(x)), Low=as.numeric(quantmod::Lo(x)),
                   Close=close, Volume=as.numeric(quantmod::Vo(x)))
  df$SMA_short <- as.numeric(TTR::SMA(close, n=short_n))
  df$SMA_long  <- as.numeric(TTR::SMA(close, n=long_n))
  df$RSI <- as.numeric(TTR::RSI(close, n=rsi_n))
  if (n >= slow_n + signal_n) {
    m <- TTR::MACD(close, nFast=fast_n, nSlow=slow_n, nSig=signal_n, maType='EMA', percent=FALSE)
    df$MACD <- as.numeric(m[,1]); df$MACD_signal <- as.numeric(m[,2])
  } else {
    df$MACD <- rep(NA_real_,n); df$MACD_signal <- rep(NA_real_,n)
  }
  df$MACD_hist <- df$MACD - df$MACD_signal
  # Trading signals are based on actual crossovers, not persistent MA ordering.
  df$Signal <- rep('Hold', n)
  if (n >= 2) for(i in 2:n) {
    prev_short <- df$SMA_short[i-1]; prev_long <- df$SMA_long[i-1]
    current_short <- df$SMA_short[i]; current_long <- df$SMA_long[i]
    if (all(is.finite(c(prev_short,prev_long,current_short,current_long)))) {
      if (prev_short <= prev_long && current_short > current_long) df$Signal[i] <- 'Buy'
      else if (prev_short >= prev_long && current_short < current_long) df$Signal[i] <- 'Sell'
    }
  }
  df
}

ui <- fluidPage(
  tags$head(tags$style(HTML('
    body {background:#f5f7fb;} .well {background:white; border:1px solid #e1e7f0; border-radius:12px;}
    h2 {color:#122647;font-weight:700;} .subtitle{color:#596579;margin-bottom:17px;}
    .metric {background:white;border:1px solid #e1e7f0;border-radius:10px;padding:14px;margin-bottom:12px;}
    .metric strong{font-size:20px;display:block;color:#172d50;}'))),
  titlePanel('Portfolio Technical Analysis | BDA400 A06'),
  div(class='subtitle', 'Yahoo Finance data • selectable OHLC timeframe • SMA, RSI, MACD • crossover buy/sell signals'),
  sidebarLayout(
    sidebarPanel(width=3,
      textInput('ticker','Stock symbol',value='AAPL'),
      selectInput('preset','Portfolio quick select',choices=c('Apple'='AAPL','Microsoft'='MSFT','Alphabet'='GOOG','NVIDIA'='NVDA','Tesla'='TSLA'),selected='AAPL'),
      dateRangeInput('dates','Date range',start=Sys.Date()-730,end=Sys.Date(),max=Sys.Date()),
      selectInput('timeframe','Time frame',choices=c('Daily','Weekly','Monthly')),
      selectInput('chart_type','Price chart',choices=c('Line','Candlestick','Area')),
      checkboxGroupInput('indicators','Technical indicators',choices=c('Moving Averages','RSI','MACD'),selected=c('Moving Averages','RSI','MACD')),
      checkboxInput('show_signals','Annotate Buy / Sell crossovers',TRUE),
      sliderInput('short','Short SMA bars',min=3,max=40,value=20),
      sliderInput('long','Long SMA bars',min=15,max=150,value=50),
      numericInput('rsi_period','RSI bars',value=14,min=2,max=100),
      tags$hr(), actionButton('refresh','Fetch / refresh Yahoo Finance',class='btn-primary'),
      tags$p('Weekly/monthly bars may yield fewer indicators. Move start date back for a longer history.'),
      tags$small('Educational demonstration only; trading signals are not investment advice.')
    ),
    mainPanel(width=9,
      uiOutput('metrics'),
      plotOutput('price_chart',height='440px'),
      conditionalPanel(condition="input.indicators.includes('RSI')",plotOutput('rsi_chart',height='210px')),
      conditionalPanel(condition="input.indicators.includes('MACD')",plotOutput('macd_chart',height='230px')),
      h4('Latest bars and signals'),tableOutput('recent'),
      downloadButton('download','Export current analysis to CSV'),
      tags$br(),tags$br(),textOutput('source_note')
    )
  )
)

server <- function(input, output, session) {
  observeEvent(input$preset, {updateTextInput(session,'ticker',value=input$preset)},ignoreInit=TRUE)
  # Fetch when symbol, dates or refresh is changed; maintain strict date validation.
  raw_data <- reactive({
    input$refresh
    sym <- validate_symbol(input$ticker)
    start <- as.Date(input$dates[1]); end <- as.Date(input$dates[2])
    validate(need(!is.na(start)&&!is.na(end)&&start < end,'Choose a valid date range.'))
    withProgress(message=paste('Fetching',sym,'from Yahoo Finance'),value=.35,{
      tryCatch(quantmod::getSymbols(sym,src='yahoo',from=start,to=end+1,auto.assign=FALSE,
                                   warnings=FALSE),error=function(e) {
        validate(need(FALSE,paste('Yahoo Finance request failed:',conditionMessage(e))))
      })
    })
  })
  analysis <- reactive({
    validate(need(input$short < input$long,'Short SMA must be smaller than long SMA.'))
    x <- resample_ohlcv(raw_data(), input$timeframe)
    validate(need(NROW(x)>=2,'Not enough price records; expand the date range.'))
    make_analysis(x, input$short, input$long, input$rsi_period, 12,26,9)
  })
  output$metrics <- renderUI({
    d <- analysis(); last <- tail(d,1); previous <- if(nrow(d)>1) d$Close[nrow(d)-1] else NA_real_
    change <- if(is.finite(previous)&&previous>0) (last$Close/previous-1)*100 else NA_real_
    fluidRow(
      column(4,div(class='metric', 'LAST CLOSE',tags$strong(sprintf('$%.2f',last$Close)))),
      column(4,div(class='metric', 'BAR CHANGE',tags$strong(ifelse(is.finite(change),sprintf('%+.2f%%',change),'N/A')))),
      column(4,div(class='metric', 'MOST RECENT SIGNAL',tags$strong(last$Signal)))
    )
  })
  output$price_chart <- renderPlot({
    d <- analysis(); p <- ggplot(d,aes(x=Date))
    if (input$chart_type=='Line') p <- p+geom_line(aes(y=Close),color='#2364b1',linewidth=.8)
    if (input$chart_type=='Area') p <- p+geom_area(aes(y=Close),fill='#6aa9df',alpha=.5)+geom_line(aes(y=Close),color='#2364b1')
    if (input$chart_type=='Candlestick') {
      d$Direction <- ifelse(d$Close>=d$Open,'Up','Down')
      p <- ggplot(d,aes(x=Date))+geom_linerange(aes(ymin=Low,ymax=High,color=Direction),linewidth=.4)+
        geom_segment(aes(xend=Date,y=Open,yend=Close,color=Direction),linewidth=3)+
        scale_color_manual(values=c('Up'='#16875d','Down'='#bd3948'))
    }
    if ('Moving Averages' %in% input$indicators) {
      p<-p+geom_line(data=d,aes(y=SMA_short),color='#e4a019',linewidth=.8,na.rm=TRUE)+
        geom_line(data=d,aes(y=SMA_long),color='#a34caf',linewidth=.8,na.rm=TRUE)
    }
    if (isTRUE(input$show_signals)) {
      marks <- d[d$Signal!='Hold',,drop=FALSE]
      if (nrow(marks)) p<-p+geom_point(data=marks,aes(y=Close,color=Signal),size=3,shape=17)+
        geom_text(data=marks,aes(y=Close,label=Signal),vjust=-.8,size=3,check_overlap=TRUE)
    }
    p+labs(title=paste(validate_symbol(input$ticker),'-',input$timeframe,'OHLC price'),
           subtitle='SMA: gold = short, purple = long; markers show actual crossover events',y='Price (USD)',x=NULL)+
      theme_minimal(base_size=12)+theme(legend.position='bottom')
  })
  output$rsi_chart <- renderPlot({
    d<-analysis()
    ggplot(d,aes(Date,RSI))+geom_hline(yintercept=c(30,70),linetype='dashed',color='#999999')+
      geom_line(color='#7545ac',linewidth=.8,na.rm=TRUE)+coord_cartesian(ylim=c(0,100))+
      labs(title=paste('Relative Strength Index (RSI)',input$rsi_period),y='RSI',x=NULL)+theme_minimal()
  })
  output$macd_chart <- renderPlot({
    d<-analysis()
    ggplot(d,aes(Date))+geom_col(aes(y=MACD_hist),fill='#99c9d0',na.rm=TRUE)+
      geom_line(aes(y=MACD),color='#2565b0',linewidth=.7,na.rm=TRUE)+
      geom_line(aes(y=MACD_signal),color='#e29d1c',linewidth=.7,na.rm=TRUE)+
      labs(title='MACD (12,26,9): blue MACD, gold signal, bars histogram',x=NULL,y='MACD')+theme_minimal()
  })
  output$recent<-renderTable({
    d<-analysis(); tail(d[,c('Date','Close','SMA_short','SMA_long','RSI','Signal')],10)
  },digits=2,striped=TRUE)
  output$download<-downloadHandler(filename=function() paste0(validate_symbol(input$ticker),'_analysis.csv'),
    content=function(file) write.csv(analysis(),file,row.names=FALSE))
  output$source_note<-renderText({paste('Source: Yahoo Finance via quantmod |',nrow(analysis()),
    'aggregated bars | Prices are unadjusted closes (corporate actions may affect historical continuity).')})
}
shinyApp(ui,server)
